<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Product;
use App\Models\DigitalCard;
use App\Models\HomeSection;
use App\Models\HomeSlider;
use App\Models\SiteReview;
use App\Facades\Theme;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Models\Review;

class HomeController extends Controller
{
    /**
     * عرض الصفحة الرئيسية للموقع
     *
     * @return \Illuminate\Contracts\View\View
     */
    public function index()
    {
        // استرجاع الأقسام النشطة مرتبة حسب الترتيب
        $homeSections = HomeSection::where('is_active', true)
            ->orderBy('order')
            ->get();
        
        // البيانات الأخرى التي قد تحتاجها الصفحة الرئيسية
        $sliders = HomeSlider::getActive();
        
        // المنتجات المميزة للقسم الافتراضي
        $featuredProducts = Product::featured()->available()
            ->withAvg(['reviews' => function($query) {
                $query->where('is_approved', true);
            }], 'rating')
            ->latest()
            ->limit(8)
            ->get();
        
        // أحدث المنتجات للقسم الافتراضي
        $latestProducts = Product::available()
            ->withAvg(['reviews' => function($query) {
                $query->where('is_approved', true);
            }], 'rating')
            ->latest()
            ->limit(8)
            ->get();
        
        // الأكثر مبيعاً للقسم الافتراضي
        $bestSellers = Product::available()
            ->withAvg(['reviews' => function($query) {
                $query->where('is_approved', true);
            }], 'rating')
            ->orderBy('sales_count', 'desc')
            ->limit(8)
            ->get();
        
        // الفئات
        $categories = Category::where('is_active', 1)
    ->where('show_in_homepage', 1)
    ->withCount('products')
    ->orderBy('sort_order')
    ->limit(14)
    ->get();
        
        // آراء العملاء - من جدول site_reviews
        $reviews = SiteReview::with('user')
            ->where('is_approved', true)
            ->orderBy('created_at', 'desc')
            ->limit(5)
            ->get();

        return view('themes.default.pages.home', compact(
            'homeSections',
            'sliders',
            'featuredProducts',
            'latestProducts',
            'bestSellers',
            'categories',
            'reviews'
        ));
    }

    public function reviews(): MorphMany
    {
        return $this->morphMany(Review::class, 'reviewable');
    }
} 