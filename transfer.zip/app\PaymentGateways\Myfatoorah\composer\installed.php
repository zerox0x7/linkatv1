<?php return array (
  'root' => 
  array (
    'pretty_version' => '1.0.0+no-version-set',
    'version' => '1.0.0.0',
    'aliases' => 
    array (
    ),
    'reference' => NULL,
    'name' => '__root__',
  ),
  'versions' => 
  array (
    '__root__' => 
    array (
      'pretty_version' => '1.0.0+no-version-set',
      'version' => '1.0.0.0',
      'aliases' => 
      array (
      ),
      'reference' => NULL,
    ),
    'myfatoorah/laravel-package' => 
    array (
      'pretty_version' => '2.2.4',
      'version' => '2.2.4.0',
      'aliases' => 
      array (
      ),
      'reference' => '4bb8ce82639c06697e04b701569d35e72a00f591',
    ),
    'myfatoorah/library' => 
    array (
      'pretty_version' => '2.2.8',
      'version' => '2.2.8.0',
      'aliases' => 
      array (
      ),
      'reference' => 'd276914fe0064147c798c59d9b05f75f7f575c4c',
    ),
  ),
);
