<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Coupon extends Model
{
    use HasFactory;

    protected $fillable = [
        'code',
        'type',
        'value',
        'starts_at',
        'expires_at',
        'max_uses',
        'used_times',
        'min_order_amount',
        'is_active',
        'product_ids',
        'category_ids'
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'value' => 'decimal:2',
        'min_order_amount' => 'decimal:2',
        'starts_at' => 'datetime',
        'expires_at' => 'datetime',
    ];

    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    public function scopeCurrent($query)
    {
        return $query
            ->where('is_active', true)
            ->where(function ($query) {
                $query->whereNull('starts_at')
                      ->orWhere('starts_at', '<=', now());
            })
            ->where(function ($query) {
                $query->whereNull('expires_at')
                      ->orWhere('expires_at', '>=', now());
            })
            ->where(function ($query) {
                $query->whereNull('max_uses')
                      ->orWhereRaw('used_times < max_uses');
            });
    }

    public function isValid()
    {
        // Check if coupon is active
        if (!$this->is_active) {
            return false;
        }

        // Check if coupon has started
        if ($this->starts_at && $this->starts_at > now()) {
            return false;
        }

        // Check if coupon has expired
        if ($this->expires_at && $this->expires_at < now()) {
            return false;
        }

        // Check if coupon has reached max uses
        if ($this->max_uses && $this->used_times >= $this->max_uses) {
            return false;
        }

        return true;
    }

    public function calculateDiscount($amount)
    {
        if (!$this->isValid()) {
            return 0;
        }

        // Check minimum order amount
        if ($this->min_order_amount && $amount < $this->min_order_amount) {
            return 0;
        }

        if ($this->type === 'percentage') {
            return ($amount * $this->value) / 100;
        }

        if ($this->type === 'fixed') {
            return min($this->value, $amount); // لا يتجاوز قيمة المنتجات المطابقة
        }

        return 0;
    }

    public function incrementUsage()
    {
        $this->increment('used_times');
    }

    public function orders()
    {
        // إذا كان الربط عبر coupon_code
        return $this->hasMany(\App\Models\Order::class, 'coupon_code', 'code');
        // إذا كان الربط عبر coupon_id استخدم:
        // return $this->hasMany(\App\Models\Order::class, 'coupon_id');
    }
} 