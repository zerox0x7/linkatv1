<?php

namespace Database\Seeders;

use App\Models\Setting;
use Illuminate\Database\Seeder;

class HeaderSettingsSeeder extends Seeder
{
    /**
     * تشغيل بذرة إعدادات الهيدر.
     *
     * @return void
     */
    public function run()
    {
        $settings = [
            // معلومات المتجر الأساسية
            'store_name' => 'متجر الحسابات',
            'store_description' => 'منصة متكاملة لبيع وشراء حسابات الألعاب ومواقع التواصل الاجتماعي بطريقة آمنة وسريعة',
            
            // الألوان الرئيسية
            'primary_color' => 'primary',
            'secondary_color' => 'secondary',
            
            // نصوص الهيدر
            'search_placeholder' => 'ابحث عن حسابات الألعاب أو السوشيال ميديا...',
            'login_text' => 'تسجيل الدخول',
            'logout_text' => 'تسجيل الخروج',
            
            // نصوص القائمة
            'home_text' => 'الرئيسية',
            'games_accounts_text' => 'حسابات الألعاب',
            'social_accounts_text' => 'حسابات السوشيال',
            'featured_text' => 'العروض المميزة',
            'best_sellers_text' => 'الأكثر مبيعاً',
            'dark_mode_text' => 'الوضع الداكن',
        ];
        
        foreach ($settings as $key => $value) {
            // تحقق إذا كانت الإعدادات موجودة بالفعل
            if (Setting::where('key', $key)->exists()) {
                continue; // تخطي إذا كان موجود
            }
            
            // إضافة الإعدادات الجديدة
            Setting::create([
                'key' => $key,
                'value' => $value,
            ]);
        }
        
        $this->command->info('تم إضافة إعدادات الهيدر الافتراضية بنجاح!');
    }
} 