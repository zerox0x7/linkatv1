<?php

return [
    'api_key' => '65772560a21de',
    'instance_id' => '676385959CF72',
    'enable_notifications' => '1',
    'admin_phones' => '966533402404',
];
